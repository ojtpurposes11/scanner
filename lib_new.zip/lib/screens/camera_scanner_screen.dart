import 'dart:async';
import 'dart:math';
import 'dart:typed_data';
import 'dart:io';
import 'dart:ui' as ui;
import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import '../services/firestore_service.dart';
import '../services/roboflow_service.dart';
import '../models/vehicle_model.dart';
import '../widgets/vehicle_result_popup.dart';

// ── Frame dimensions ──────────────────────────────────────────────
const double _kFrameW = 300.0;
const double _kFrameH = 100.0;
// Vertical offset for the scan frame (negative moves the frame upward).
// Set to 0 to keep the frame centered.
const double _kFrameYOffsetFraction = 0.0;

// Require this fraction of the OCR element to be within the scan frame
// in order for it to be considered. This prevents partial detections from
// being used during auto-scan.
const double _kMinFrameOverlapFraction = 0.75;

// ── Auto-scan tuning ──────────────────────────────────────────────
const int      _kStreak   = 1;                           // consecutive identical reads (reduced from 4 for faster detection)
const Duration _kCooldown = Duration(milliseconds: 220); // gap between OCR calls (lower is faster but more CPU)

// ── Philippine plate regexes ──────────────────────────────────────
final _rxPlate = RegExp(r'^[A-Z]{3}[0-9]{4}$');          // NHM4030
final _rxOld   = RegExp(r'^[A-Z]{3}[0-9]{3}$');          // ABC123
final _rxCS    = RegExp(r'^[A-Z]{2}[0-9]{4}[A-Z]?$');    // RB0827 / RB0827A

bool _isValid(String s) =>
    _rxPlate.hasMatch(s) || _rxOld.hasMatch(s) || _rxCS.hasMatch(s);

// ─────────────────────────────────────────────────────────────────
class CameraScannerScreen extends StatefulWidget {
  const CameraScannerScreen({super.key});
  @override
  State<CameraScannerScreen> createState() => _CameraScannerScreenState();
}

class _CameraScannerScreenState extends State<CameraScannerScreen>
    with WidgetsBindingObserver {

  CameraController? _ctrl;
  bool    _cameraReady = false;
  bool    _isDisposed = false;
  String? _cameraError;

  final _ocr = TextRecognizer();
  final _db  = FirestoreService();
  final _roboflow = RoboflowService();

  // Auto-scan
  Timer?   _autoTimer;
  DateTime _lastFrame  = DateTime.fromMillisecondsSinceEpoch(0);

  // Gate — prevents overlapping OCR calls
  bool     _processing = false;

  // State
  bool _resultShown = false; // true while bottom sheet is open
  bool _manualBusy  = false; // true while manual capture is processing


  // Streak
  String? _streakPlate;
  int     _streakCount = 0;

  // Fast-search support: if a plate is already known to be in the DB,
  // show results immediately without waiting for further streaks.
  String? _pendingSearchPlate;
  Future<void>? _pendingSearch;

  // Cache recent DB search results so repeating a plate returns instantly.
  final _dbSearchCache = <String, List<VehicleModel>>{};
  final _dbNoRecordCache = <String, DateTime>{};
  static const _kCacheTTL = Duration(minutes: 5);

  // UI
  String  _hint       = 'Align plate inside the frame';
  String? _reading;           // plate currently building streak
  bool    _isScanning = false; // OCR in progress
  String? _noRecordMsg;        // inline "no record" message for auto-scan

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initCamera();
  }

  @override
  void dispose() {
    _isDisposed = true;
    WidgetsBinding.instance.removeObserver(this);
    _autoTimer?.cancel();
    _autoTimer = null;


    // Ensure the stream is fully stopped before disposing the controller.
    // Disposing a CameraController while it still has active listeners can
    // trigger `_dependents.isEmpty` assertion failures in the plugin.
    if (_ctrl != null) {
      final stopFuture = _ctrl!.value.isStreamingImages
          ? _ctrl!.stopImageStream().catchError((_) {})
          : Future.value();
      stopFuture.whenComplete(() => _ctrl?.dispose());
    }

    _ocr.close();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (_isDisposed) return;
    if (s == AppLifecycleState.inactive) unawaited(_stopStream());
    if (s == AppLifecycleState.resumed && _cameraReady) _startStream();
  }

  // ── Camera ────────────────────────────────────────────────────
  Future<void> _initCamera() async {
    try {
      final cams = await availableCameras();
      if (cams.isEmpty) { setState(() => _cameraError = 'No camera found.'); return; }
      final cam = cams.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => cams.first,
      );
      // Use a lower resolution to speed up OCR and reduce processing latency.
      // High resolution gives better detail but is slower; medium is usually sufficient
      // for license plates and improves responsiveness.
      _ctrl = CameraController(cam, ResolutionPreset.medium,
          enableAudio: false, imageFormatGroup: ImageFormatGroup.nv21);
      await _ctrl!.initialize();
      await _ctrl!.setFocusMode(FocusMode.auto);
      await _ctrl!.setFlashMode(FlashMode.off);
      await _ctrl!.setExposureMode(ExposureMode.auto);
      if (mounted) {
        setState(() => _cameraReady = true);
        _startStream();
      }
    } catch (e) {
      if (mounted) setState(() => _cameraError = 'Camera error: $e');
    }
  }

  // ── Auto-scan: image stream ───────────────────────────────────
  // Camera delivers raw NV21 frames at ~30fps.
  // We pass the FULL frame to ML Kit (no byte slicing — that was
  // the bug before). The height-filter in _parsePlate ignores all
  // small surrounding text, so we don't need to crop the image.
  // A cooldown gate (controlled by _kCooldown) prevents overlapping OCR calls.
  // Result: ~200-300ms per scan vs ~700ms+ for takePicture().
  void _startStream() {
    if (_isDisposed || _ctrl == null || _ctrl!.value.isStreamingImages) return;
    _ctrl!.startImageStream(_onFrame).catchError((_) {});
  }

  Future<void> _stopStream() async {
    _autoTimer?.cancel();
    _autoTimer = null;
    if (_ctrl == null || !_ctrl!.value.isStreamingImages) return;

    try {
      await _ctrl!.stopImageStream();
    } catch (_) {
      // ignore
    }
  }

  void _onFrame(CameraImage image) {
    if (_isDisposed || _processing || _resultShown || _manualBusy) return;
    final now = DateTime.now();
    if (now.difference(_lastFrame) < _kCooldown) return;
    _lastFrame  = now;
    _processing = true;
    if (mounted) setState(() => _isScanning = true);
    _processFrame(image).whenComplete(() {
      _processing = false;
      if (mounted) setState(() => _isScanning = false);
    });
  }

  Future<void> _processFrame(CameraImage image) async {
    if (_isDisposed) return;
    try {
      // Build InputImage from raw NV21 — full frame, no slicing.
      // TODO: If still slow, consider cropping/resizing to the scan box only.
      final inputImage = _nv21ToInputImage(image);
      if (inputImage == null) return;

      // Calculate the approximate scan frame region in image coordinates.
      // This lets us ignore OCR results that come from outside the box.
      final frameRect = _getFrameRectForImage(image);

      // For speed, skip Roboflow (network call) and rely on local OCR + frame filtering.
      // This keeps auto-scan responsive (few seconds) and avoids per-frame HTTP overhead.
      final result = await _ocr.processImage(inputImage);
      
      if (!mounted || _resultShown) return;

      final plate = _parsePlate(result, frameRect);
      if (plate == null) {
        if (_streakCount > 0) {
          _streakPlate = null; _streakCount = 0;
          if (mounted) setState(() {
            _reading = null;
            _hint    = 'Align plate inside the frame';
          });
        }
        return;
      }

      // If we already have cached DB results for this plate, show them immediately.
      // This makes auto-scan feel much faster for known plates.
      final cached = _dbSearchCache[plate];
      if (cached != null && cached.isNotEmpty) {
        if (!mounted || _resultShown) return;
        if (mounted) setState(() => _resultShown = true);
        _showResult(cached, plate);
        return;
      }

      // If we already recently determined this plate is not in the DB,
      // skip repeated lookups and keep scanning.
      if (_dbNoRecordCache.containsKey(plate)) {
        if (!mounted) return;
        if (mounted) setState(() {
          _noRecordMsg = 'No record found for  $plate';
          _hint        = 'Align plate inside the frame';
        });
        return;
      }

      // Build streak
      if (plate == _streakPlate) {
        _streakCount++;
      } else {
        _streakPlate = plate; _streakCount = 1;
        if (mounted && _noRecordMsg != null) setState(() => _noRecordMsg = null);
      }

      if (mounted) setState(() {
        _reading = plate;
        _hint    = 'Reading ($_streakCount/$_kStreak)...';
      });

      // Kick off a fast DB lookup; if it finds a matching vehicle we show it immediately.
      // This happens in parallel with the streak build so we can return results
      // as soon as the DB responds.
      _maybeStartSearch(plate);

      if (_streakCount < _kStreak) return;

      // ── Confirmed — search DB (fallback if the fast path hasn't already shown results)
      _streakPlate = null; _streakCount = 0;
      if (mounted) setState(() { _reading = null; _hint = 'Searching...'; });

      final results = await _dbSearch(plate);
      if (!mounted || _resultShown) return;

      if (results.isNotEmpty) {
        // ✅ Found — show result popup
        if (mounted) setState(() => _resultShown = true);
        _showResult(results, plate);
      } else {
        // ❌ Not in DB — inline banner, keep scanning
        if (mounted) setState(() {
          _noRecordMsg = 'No record found for  $plate';
          _hint        = 'Align plate inside the frame';
        });
        _autoTimer?.cancel();
        _autoTimer = Timer(const Duration(seconds: 3), () {
          if (mounted) setState(() => _noRecordMsg = null);
        });
      }
    } catch (_) { /* silent frame error */ }
  }

  /// Attempts a quick DB lookup for [plate] and shows the result immediately
  /// if the plate exists.
  void _maybeStartSearch(String plate) {
    // If we already have an in-progress or completed query for this plate, skip.
    if (_pendingSearchPlate == plate && _pendingSearch != null) return;

    _pendingSearchPlate = plate;
    _pendingSearch = () async {
      final results = await _dbSearch(plate);
      _pendingSearch = null;
      if (!mounted || _resultShown) return;
      // If the plate has changed since we started, ignore the old result.
      if (plate != _pendingSearchPlate) return;
      if (results.isNotEmpty) {
        if (mounted) setState(() => _resultShown = true);
        _showResult(results, plate);
      }
    }();
  }

  // ── Convert CameraImage (NV21) → InputImage for ML Kit ────────
  // NV21 format = Y plane + interleaved VU plane.
  // Must concatenate ALL planes into one buffer for ML Kit to decode
  // the image correctly. Passing only plane[0] gives ML Kit a
  // grayscale-only buffer which produces poor OCR results.
  InputImage? _nv21ToInputImage(CameraImage image) {
    try {
      // Concatenate all plane bytes into a single NV21 buffer
      int totalBytes = 0;
      for (final p in image.planes) totalBytes += p.bytes.length;
      final nv21 = Uint8List(totalBytes);
      int offset = 0;
      for (final p in image.planes) {
        nv21.setRange(offset, offset + p.bytes.length, p.bytes);
        offset += p.bytes.length;
      }

      return InputImage.fromBytes(
        bytes: nv21,
        metadata: InputImageMetadata(
          size:        Size(image.width.toDouble(), image.height.toDouble()),
          rotation:    InputImageRotation.rotation90deg,
          format:      InputImageFormat.nv21,
          bytesPerRow: image.planes[0].bytesPerRow,
        ),
      );
    } catch (_) { return null; }
  }

  /// Returns the approximate crop rectangle of the scan box in the raw image
  /// coordinate space.
  ///
  /// This allows us to ignore OCR results detected outside the visible
  /// scan frame, which improves accuracy when the camera sees text outside
  /// the target box.
  Rect? _getFrameRectForImage(CameraImage image) {
    if (_ctrl == null || !_ctrl!.value.isInitialized) return null;

    final prev = _ctrl!.value.previewSize;
    if (prev == null) return null;

    // The preview's width/height are swapped relative to the raw image.
    // This matches the transformation used in _cropToFrame.
    final prevW = prev.height;
    final prevH = prev.width;

    final imgW = image.width.toDouble();
    final imgH = image.height.toDouble();

    final sx = imgW / prevW;
    final sy = imgH / prevH;

    const padX = 56.0;
    const padY = 20.0;

    final fl = ((prevW - _kFrameW) / 2 - padX) * sx;
    final ft = (((prevH - _kFrameH) / 2 - padY) + (prevH / 2) * _kFrameYOffsetFraction) * sy;
    final fw = (_kFrameW + padX * 2) * sx;
    final fh = (_kFrameH + padY * 2) * sy;

    final left = fl.clamp(0.0, imgW - 1);
    final top = ft.clamp(0.0, imgH - 1);
    final right = (left + fw).clamp(0.0, imgW);
    final bottom = (top + fh).clamp(0.0, imgH);

    return Rect.fromLTRB(left, top, right, bottom);
  }

  // ── Manual capture ─────────────────────────────────────────────
  // Always available — no mode switching needed.
  // Flow: tap → freeze frame → "Captured!" → Roboflow detect → crop → OCR →
  //       confirm dialog (editable) → search → result popup
  Future<void> _manualCapture() async {
    if (_manualBusy || _resultShown) return;
    if (_ctrl == null || !_ctrl!.value.isInitialized) return;

    // Pause auto-scan while capturing (resume after)
    await _stopStream();
    if (!mounted) return;
    setState(() { _manualBusy = true; _reading = null; _noRecordMsg = null; _hint = 'Capturing...'; });

    String? filePath;
    try {
      // Step 1: Take picture (camera freezes — gives user visual feedback)
      final file = await _ctrl!.takePicture();
      filePath = file.path;

      // Step 2: Show "captured" feedback before analyzing
      if (!mounted) return;
      setState(() => _hint = 'Photo captured! Analyzing...');
      await Future.delayed(const Duration(milliseconds: 350));
      if (!mounted) return;

      // Step 3: Use Roboflow for plate detection + OCR
      setState(() => _hint = 'Detecting plate with AI...');
      final imageBytes = await File(filePath).readAsBytes();
      
      // Try Roboflow detection first
      final detections = await _roboflow.detectPlates(imageBytes);
      final bestDetection = _roboflow.getBestDetection(detections);
      
      String? cropped;
      RecognizedText result;
      
      if (bestDetection != null) {
        // Step 3a: Crop using Roboflow bounding box (more accurate!)
        setState(() => _hint = 'AI detected plate! Reading text...');
        cropped = await _cropToRoboflowBox(filePath, bestDetection);
        final input = InputImage.fromFilePath(cropped);
        result = await _ocr.processImage(input);
      } else {
        // Step 3b: Fall back to original frame-based crop
        setState(() => _hint = 'Reading plate...');
        cropped = await _cropToFrame(filePath);
        final input = InputImage.fromFilePath(cropped);
        result = await _ocr.processImage(input);
      }

      try { File(filePath).deleteSync(); } catch (_) {}
      try { File(cropped).deleteSync(); } catch (_) {}
      filePath = null;

      if (!mounted) return;

      // Step 4: If we are confident the plate exists in the DB, show results immediately.
      // Otherwise fall back to the confirmation dialog.
      final plate = _parsePlate(result);
      if (plate != null) {
        final results = await _dbSearch(plate);
        if (!mounted) return;
        if (results.isNotEmpty) {
          if (mounted) setState(() => _resultShown = true);
          _showResult(results, plate);
          return;
        }
      }

      await _confirmAndSearch(plate ?? '');

    } catch (_) {
      try {
        if (filePath != null) File(filePath).deleteSync();
      } catch (_) {}
      if (mounted) setState(() => _hint = 'Capture failed — try again');
      await Future.delayed(const Duration(seconds: 2));
      if (mounted) setState(() => _hint = 'Align plate inside the frame');
    } finally {
      // Don't resume auto-scan here - let _resetState() handle it after result popup closes
      if (mounted) setState(() => _manualBusy = false);
    }
  }

  // Crop image using Roboflow detection bounding box
  Future<String> _cropToRoboflowBox(String path, PlateDetection detection) async {
    final bytes = await File(path).readAsBytes();
    final codec = await ui.instantiateImageCodec(bytes);
    final frm = await codec.getNextFrame();
    final img = frm.image;
    
    // Get bounding box (center-based to corner-based)
    final (left, top, right, bottom) = detection.boundingBox;
    
    // Add padding around the detection
    const padding = 10;
    final cl = (left - padding).clamp(0, img.width - 1);
    final ct = (top - padding).clamp(0, img.height - 1);
    final cw = (right - left + padding * 2).clamp(1, img.width - cl);
    final ch = (bottom - top + padding * 2).clamp(1, img.height - ct);
    
    final rec = ui.PictureRecorder();
    Canvas(rec).drawImageRect(
      img,
      Rect.fromLTWH(cl.toDouble(), ct.toDouble(), cw.toDouble(), ch.toDouble()),
      Rect.fromLTWH(0, 0, cw.toDouble(), ch.toDouble()),
      Paint(),
    );
    final cropped = await rec.endRecording().toImage(cw, ch);
    final pngBytes = await cropped.toByteData(format: ui.ImageByteFormat.png);
    final out = '${path}_roboflow_crop.png';
    await File(out).writeAsBytes(pngBytes!.buffer.asUint8List());
    return out;
  }

  // ── Confirm dialog ────────────────────────────────────────────
  Future<void> _confirmAndSearch(String detected) async {
    // Stop stream completely before showing confirm
    await _stopStream();
    if (_isDisposed) return;
    if (!mounted) return;

    // Use a standard showDialog — simpler and avoids overlay lifecycle issues.
    final confirmed = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => _ConfirmDialog(detected: detected),
    );

    // If cancelled or not mounted, resume stream and return
    if (!mounted || confirmed == null || confirmed.isEmpty) {
      if (mounted) _startStream();
      return;
    }

    // Search and show result (found OR not found — always show popup)
    if (mounted) setState(() => _hint = 'Searching $confirmed...');
    final results = await _dbSearch(confirmed);
    if (!mounted) return;
    setState(() => _resultShown = true);
    _showResult(results, confirmed);
  }



  // ── File crop for manual capture ──────────────────────────────
  Future<String> _cropToFrame(String path) async {
    final bytes  = await File(path).readAsBytes();
    final codec  = await ui.instantiateImageCodec(bytes);
    final frm    = await codec.getNextFrame();
    final img    = frm.image;
    final imgW   = img.width.toDouble();
    final imgH   = img.height.toDouble();
    final prev   = _ctrl!.value.previewSize!;
    final prevW  = prev.height;
    final prevH  = prev.width;
    final sx     = imgW / prevW;
    final sy     = imgH / prevH;
    const padX = 56.0; const padY = 20.0;
    final fl = ((prevW - _kFrameW) / 2 - padX) * sx;
    final ft = (((prevH - _kFrameH) / 2 - padY) + (prevH / 2) * _kFrameYOffsetFraction) * sy;
    final fw = (_kFrameW + padX * 2) * sx;
    final fh = (_kFrameH + padY * 2) * sy;
    final cl = fl.clamp(0.0, imgW - 1).toInt();
    final ct = ft.clamp(0.0, imgH - 1).toInt();
    final cw = fw.clamp(1.0, imgW - cl).toInt();
    final ch = fh.clamp(1.0, imgH - ct).toInt();
    final rec = ui.PictureRecorder();
    Canvas(rec).drawImageRect(img,
      Rect.fromLTWH(cl.toDouble(), ct.toDouble(), cw.toDouble(), ch.toDouble()),
      Rect.fromLTWH(0, 0, cw.toDouble(), ch.toDouble()), Paint());
    final cropped  = await rec.endRecording().toImage(cw, ch);
    final pngBytes = await cropped.toByteData(format: ui.ImageByteFormat.png);
    final out = '${path}_crop.png';
    await File(out).writeAsBytes(pngBytes!.buffer.asUint8List());
    return out;
  }

  // ── Plate parsing ─────────────────────────────────────────────
  String? _parsePlate(RecognizedText ocr, [Rect? frameRect]) {
    final all = <({String text, double h})>[];
    for (final block in ocr.blocks) {
      for (final line in block.lines) {
        for (final el in line.elements) {
          final pts = el.cornerPoints;
          if (pts.length < 2) continue;

          // Ignore any text outside the visible scan frame (usually at the top).
          // Use a stricter filter: only accept OCR elements that are mostly inside the frame.
          if (frameRect != null) {
            final xs = pts.map((p) => p.x.toDouble());
            final ys = pts.map((p) => p.y.toDouble());
            final rect = Rect.fromLTRB(xs.reduce(min), ys.reduce(min), xs.reduce(max), ys.reduce(max));

            // Require a minimum fraction of the element to fall inside the frame
            // so partial/edge detections are discarded.
            final intersection = rect.intersect(frameRect);
            if (intersection.isEmpty) continue;

            final elementArea = rect.width * rect.height;
            if (elementArea <= 0) continue;
            final overlapRatio = (intersection.width * intersection.height) / elementArea;
            if (overlapRatio < _kMinFrameOverlapFraction) continue;
          }

          double minY = pts[0].y.toDouble(), maxY = pts[0].y.toDouble();
          for (final pt in pts) {
            if (pt.y < minY) minY = pt.y.toDouble();
            if (pt.y > maxY) maxY = pt.y.toDouble();
          }
          final h    = maxY - minY;
          final text = el.text.replaceAll(RegExp(r'[^A-Za-z0-9]'), '').toUpperCase();
          if (text.isNotEmpty && h > 0) all.add((text: text, h: h));
        }
      }
    }
    if (all.isEmpty) return null;

    final sorted = all.map((e) => e.h).toList()..sort();
    final thresh = sorted.last * 0.60;

    final big = all.where((e) => e.h >= thresh).map((e) => e.text).toSet();
    return _tryTokens(big) ?? _tryTokens(all.map((e) => e.text).toSet());
  }

  String? _tryTokens(Set<String> tokens) {
    for (final token in tokens) {
      for (final len in [7, 6]) {
        if (token.length < len) continue;
        for (int i = 0; i <= token.length - len; i++) {
          final r = _fix(token.substring(i, i + len));
          if (r != null) return r;
        }
      }
    }
    final joined = tokens.where((t) => t.length <= 8).join('');
    for (final len in [7, 6]) {
      if (joined.length < len) continue;
      for (int i = 0; i <= joined.length - len; i++) {
        final r = _fix(joined.substring(i, i + len));
        if (r != null) return r;
      }
    }
    return null;
  }

  // Position-aware correction: letter zone → force letter, digit zone → force digit
  String? _fix(String s) {
    const toL = {'0':'O','1':'I','8':'B','5':'S','2':'Z','6':'G'};
    const toD = {'O':'0','I':'1','B':'8','S':'5','Z':'2','G':'6','Q':'0'};
    String L(String c) => toL[c] ?? c;
    String D(String c) => toD[c] ?? c;
    bool isLetter(String c) => c.codeUnitAt(0) >= 65 && c.codeUnitAt(0) <= 90;

    if (s.length == 7) {
      // New plate [L L L D D D D]
      final f = '${L(s[0])}${L(s[1])}${L(s[2])}${D(s[3])}${D(s[4])}${D(s[5])}${D(s[6])}';
      if (_isValid(f)) return f;
      // Conduction with trailing letter [L L D D D D L]
      final l0 = L(s[0]); final l1 = L(s[1]);
      if (isLetter(l0) && isLetter(l1)) {
        final f2 = '$l0$l1${D(s[2])}${D(s[3])}${D(s[4])}${D(s[5])}${L(s[6])}';
        if (_isValid(f2)) return f2;
      }
    }
    if (s.length == 6) {
      // Old plate [L L L D D D]
      final f = '${L(s[0])}${L(s[1])}${L(s[2])}${D(s[3])}${D(s[4])}${D(s[5])}';
      if (_isValid(f)) return f;
      // Conduction [L L D D D D]
      final l0 = L(s[0]); final l1 = L(s[1]);
      if (isLetter(l0) && isLetter(l1)) {
        final f2 = '$l0$l1${D(s[2])}${D(s[3])}${D(s[4])}${D(s[5])}';
        if (_isValid(f2)) return f2;
      }
    }
    return null;
  }

  // ── DB search ─────────────────────────────────────────────────
  Future<List<VehicleModel>> _dbSearch(String plate) async {
    plate = plate.toUpperCase();

    // Fast path: cached results
    final cached = _dbSearchCache[plate];
    if (cached != null) return cached;

    // Fast negative cache
    final noRecordAt = _dbNoRecordCache[plate];
    if (noRecordAt != null && DateTime.now().difference(noRecordAt) < _kCacheTTL) {
      return const [];
    }

    const swaps = {'B':'8','8':'B','O':'0','0':'O','I':'1','1':'I',
                   'S':'5','5':'S','Z':'2','2':'Z','G':'6','6':'G'};
    final variants = <String>{plate};
    for (int i = 0; i < plate.length; i++) {
      final alt = swaps[plate[i]];
      if (alt != null) variants.add(plate.substring(0,i)+alt+plate.substring(i+1));
    }

    final results = await Future.wait(
      variants.where(_isValid).map((v) => _db.searchVehicle(v)));
    final seen = <String>{}; final out = <VehicleModel>[];
    for (final list in results) {
      for (final v in list) {
        if (seen.add(v.plateNumber)) out.add(v);
      }
    }

    if (out.isEmpty) {
      _dbNoRecordCache[plate] = DateTime.now();
    } else {
      _dbSearchCache[plate] = out;
      _dbNoRecordCache.remove(plate);
    }

    return out;
  }

  // ── Show result ───────────────────────────────────────────────
  Future<void> _showResult(List<VehicleModel> vehicles, String plate) async {
    // Make sure the camera stream is stopped before presenting the result sheet.
    // This avoids any active callbacks or controllers remaining active while
    // the sheet is open (which can contribute to inherited widget assertion failures).
    await _stopStream();

    if (!mounted) return;

    // Show the result sheet and await the user's action. Returning a value
    // from the sheet keeps navigation logic centralized and avoids popping the
    // wrong navigator (which can lead to inherited widget assertion failures).
    final action = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      useSafeArea: true,
      builder: (sheetContext) => DraggableScrollableSheet(
        initialChildSize: vehicles.isNotEmpty ? 0.88 : 0.5,
        minChildSize: 0.4,
        maxChildSize: 0.95,
        expand: false,
        builder: (_, __) => VehicleResultPopup(
          vehicles: vehicles,
          searchedPlate: plate,
          searchMode: SearchMode.camera,
          onScanAnother: () => Navigator.of(sheetContext).pop('scanAnother'),
          onTypeSearchAnother: () => Navigator.of(sheetContext).pop('typeSearch'),
          onScanAgain: () => Navigator.of(sheetContext).pop('scanAgain'),
          onBackToDashboard: () => Navigator.of(sheetContext).pop('back'),
        ),
      ),
    );

    if (!mounted) return;

    // Reset state after the sheet has been dismissed.
    _resetState();

    // Handle optional navigation actions (e.g. returning to dashboard).
    if (action == 'typeSearch') {
      Navigator.of(context).pop('typeSearch');
    } else if (action == 'back') {
      Navigator.of(context).pop();
    }
  }

  void _resetState() {
    if (!mounted) return;
    setState(() {
      _resultShown = false; _manualBusy = false;
      _reading = null; _noRecordMsg = null;
      _streakPlate = null; _streakCount = 0;
      _hint = 'Align plate inside the frame';
    });
    _startStream();
  }

  // ── Build ─────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    if (kIsWeb) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.camera_alt_outlined, color: Colors.white54, size: 56),
          const SizedBox(height: 16),
          const Text('Camera scanning is not available on web.',
              style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 24),
          ElevatedButton(onPressed: () => Navigator.pop(context),
              child: const Text('Go Back')),
        ])),
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [

        // Camera preview
        if (_cameraReady && _ctrl != null)
          Positioned.fill(child: CameraPreview(_ctrl!))
        else if (_cameraError != null) _errorWidget()
        else const Center(child: CircularProgressIndicator(color: Color(0xFFFF0000))),

        // Dark overlay with frame cutout
        if (_cameraReady)
          Positioned.fill(child: CustomPaint(painter: _OverlayPainter())),

        // Animated scan frame + streak dots (shifted slightly upward)
        if (_cameraReady)
          Align(alignment: const Alignment(0, _kFrameYOffsetFraction),
              child: _ScanFrame(
                  streakCount: _streakCount,
                  threshold: _kStreak,
                  hasReading: _reading != null,
                  isScanning: _isScanning)),

        // ── Top bar ───────────────────────────────────────────
        SafeArea(child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(children: [
            _iconBtn(Icons.arrow_back_ios_rounded, () => Navigator.pop(context)),
            const SizedBox(width: 12),
            const Expanded(
              child: Text('Scan Plate / Conduction Sticker',
                  style: TextStyle(color: Colors.white, fontSize: 15,
                      fontWeight: FontWeight.w700)),
            ),
            // Auto-scan indicator badge (top right)
            _AutoBadge(isScanning: _isScanning, streakCount: _streakCount),
          ]),
        )),

        // ── Centre: format pills + status + no-record message ──
        if (_cameraReady)
          Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
            // Format pills
            Row(mainAxisSize: MainAxisSize.min, children: const [
              _Pill(label: 'PLATE', example: 'NHM4030'),
              SizedBox(width: 8),
              _Pill(label: 'CS', example: 'RB0827'),
            ]),
            const SizedBox(height: 10),
            const SizedBox(height: _kFrameH),
            const SizedBox(height: 14),

            // Status bubble (reading + streak bar OR hint)
            _StatusBubble(
              reading: _reading,
              hint: _hint,
              streakCount: _streakCount,
              threshold: _kStreak,
              busy: _manualBusy,
            ),

            // No-record inline message (auto-scan only)
            if (_noRecordMsg != null) ...[
              const SizedBox(height: 10),
              _NoRecordBanner(message: _noRecordMsg!),
            ],
          ])),

        // ── Bottom: manual shutter (always visible) ────────────
        if (_cameraReady)
          Positioned(
            bottom: 44, left: 0, right: 0,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              // Tip text
              Text(
                _manualBusy
                    ? _hint
                    : 'Auto-scanning  •  Tap to capture manually',
                style: TextStyle(color: Colors.white.withOpacity(0.45), fontSize: 11),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 14),

              // Shutter button — always active (both auto + manual coexist)
              GestureDetector(
                onTap: _manualBusy || _resultShown ? null : _manualCapture,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 72, height: 72,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: (_manualBusy || _resultShown)
                        ? Colors.grey[700]
                        : const Color(0xFFFF0000),
                    border: Border.all(color: Colors.white, width: 3.5),
                    boxShadow: (!_manualBusy && !_resultShown) ? [
                      BoxShadow(color: const Color(0xFFFF0000).withOpacity(0.45),
                          blurRadius: 20, spreadRadius: 3),
                    ] : [],
                  ),
                  child: _manualBusy
                      ? const Padding(padding: EdgeInsets.all(22),
                          child: CircularProgressIndicator(
                              strokeWidth: 2.5, color: Colors.white))
                      : const Icon(Icons.camera_alt_rounded,
                          color: Colors.white, size: 30),
                ),
              ),
              const SizedBox(height: 8),
              Text('Manual capture',
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.35), fontSize: 10)),
            ]),
          ),
      ]),
    );
  }

  Widget _iconBtn(IconData icon, VoidCallback onTap) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: Colors.black54,
          borderRadius: BorderRadius.circular(12)),
      child: Icon(icon, color: Colors.white, size: 18),
    ),
  );

  Widget _errorWidget() => Center(
    child: Padding(padding: const EdgeInsets.all(32),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.camera_alt_outlined, color: Colors.grey, size: 56),
        const SizedBox(height: 16),
        Text(_cameraError!, style: const TextStyle(color: Colors.white70),
            textAlign: TextAlign.center),
        const SizedBox(height: 24),
        ElevatedButton(onPressed: () => Navigator.pop(context),
            child: const Text('Go Back')),
      ]),
    ),
  );
}

// ─────────────────────────────────────────────────────────────────
// Widgets
// ─────────────────────────────────────────────────────────────────

// Auto-scan badge (top right)
class _AutoBadge extends StatefulWidget {
  final bool isScanning;
  final int streakCount;
  const _AutoBadge({required this.isScanning, required this.streakCount});
  @override State<_AutoBadge> createState() => _AutoBadgeState();
}
class _AutoBadgeState extends State<_AutoBadge>
    with SingleTickerProviderStateMixin {
  late AnimationController _dot;
  @override void initState() {
    super.initState();
    _dot = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 600))..repeat(reverse: true);
  }
  @override void dispose() { _dot.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    final color = widget.isScanning
        ? Color.lerp(const Color(0xFFFF0000), Colors.orange, _dot.value)!
        : widget.streakCount > 0
            ? const Color(0xFFFFAA00)
            : Colors.white38;
    return AnimatedBuilder(
      animation: _dot,
      builder: (_, __) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: Colors.black54,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.5)),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 6, height: 6,
            decoration: BoxDecoration(shape: BoxShape.circle, color: color,
              boxShadow: widget.isScanning ? [
                BoxShadow(color: color.withOpacity(0.6), blurRadius: 6)] : [])),
          const SizedBox(width: 5),
          Text(
            widget.isScanning ? 'Scanning' : widget.streakCount > 0 ? 'Reading' : 'Auto',
            style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w700),
          ),
        ]),
      ),
    );
  }
}

// Scan frame with streak dots
class _ScanFrame extends StatefulWidget {
  final int streakCount, threshold;
  final bool hasReading, isScanning;
  const _ScanFrame({required this.streakCount, required this.threshold,
      required this.hasReading, required this.isScanning});
  @override State<_ScanFrame> createState() => _ScanFrameState();
}
class _ScanFrameState extends State<_ScanFrame>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulse;
  @override void initState() {
    super.initState();
    _pulse = AnimationController(vsync: this,
        duration: const Duration(milliseconds: 700))..repeat(reverse: true);
  }
  @override void dispose() { _pulse.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final active  = widget.hasReading || widget.isScanning;
    final color   = widget.hasReading ? const Color(0xFFFFAA00)
        : widget.isScanning ? const Color(0xFFFF4444) : Colors.white;
    return Column(mainAxisSize: MainAxisSize.min, children: [
      // Streak confidence dots
      if (widget.hasReading)
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Row(mainAxisSize: MainAxisSize.min,
            children: List.generate(widget.threshold, (i) {
              final lit = i < widget.streakCount;
              return AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 4),
                width: lit ? 12 : 7, height: lit ? 12 : 7,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: lit ? const Color(0xFFFFAA00) : Colors.white24,
                  boxShadow: lit ? [BoxShadow(
                    color: const Color(0xFFFFAA00).withOpacity(0.7),
                    blurRadius: 8, spreadRadius: 1)] : [],
                ),
              );
            }),
          ),
        ),
      // Frame brackets
      AnimatedBuilder(
        animation: _pulse,
        builder: (_, __) => Opacity(
          opacity: active ? 0.5 + _pulse.value * 0.5 : 1.0,
          child: SizedBox(width: _kFrameW, height: _kFrameH,
              child: CustomPaint(painter: _BracketPainter(color: color))),
        ),
      ),
    ]);
  }
}

// Status bubble
class _StatusBubble extends StatelessWidget {
  final String? reading;
  final String hint;
  final int streakCount, threshold;
  final bool busy;
  const _StatusBubble({required this.reading, required this.hint,
      required this.streakCount, required this.threshold, required this.busy});

  @override
  Widget build(BuildContext context) => AnimatedSwitcher(
    duration: const Duration(milliseconds: 200),
    child: reading != null ? _readingWidget() : _hintWidget(),
  );

  Widget _readingWidget() => Container(
    key: ValueKey(reading),
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
    decoration: BoxDecoration(
      color: Colors.black.withOpacity(0.82),
      borderRadius: BorderRadius.circular(28),
      border: Border.all(color: const Color(0xFFFFAA00).withOpacity(0.8), width: 1.5),
    ),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Row(mainAxisSize: MainAxisSize.min, children: [
        const SizedBox(width: 12, height: 12,
            child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFFFFAA00))),
        const SizedBox(width: 8),
        Text(reading!, style: const TextStyle(color: Colors.white,
            fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 4)),
      ]),
      const SizedBox(height: 7),
      Row(mainAxisSize: MainAxisSize.min, children: [
        Text('Confirming  ', style: TextStyle(color: Colors.white54, fontSize: 10)),
        ...List.generate(threshold, (i) => AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          margin: const EdgeInsets.only(left: 3),
          width: 22, height: 4,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(2),
            color: i < streakCount ? const Color(0xFFFFAA00) : Colors.white,
          ),
        )),
        const SizedBox(width: 6),
        Text('$streakCount/$threshold',
            style: const TextStyle(color: Color(0xFFFFAA00),
                fontSize: 10, fontWeight: FontWeight.w700)),
      ]),
    ]),
  );

  Widget _hintWidget() => Container(
    key: const ValueKey('hint'),
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
    decoration: BoxDecoration(
        color: Colors.black, borderRadius: BorderRadius.circular(28)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      if (busy) ...[
        const SizedBox(width: 13, height: 13,
            child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFFFF0000))),
        const SizedBox(width: 8),
      ],
      Text(hint, style: const TextStyle(color: Colors.white, fontSize: 13)),
    ]),
  );
}

// No-record banner (auto-scan inline)
class _NoRecordBanner extends StatelessWidget {
  final String message;
  const _NoRecordBanner({required this.message});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
    decoration: BoxDecoration(
      color: Colors.red[900]!.withOpacity(0.88),
      borderRadius: BorderRadius.circular(24),
      border: Border.all(color: Colors.red[400]!, width: 1),
    ),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.search_off_rounded, color: Colors.white70, size: 16),
      const SizedBox(width: 8),
      Text(message,
          style: const TextStyle(color: Colors.white,
              fontSize: 13, fontWeight: FontWeight.w600)),
    ]),
  );
}

// ── Painters ──────────────────────────────────────────────────────
class _OverlayPainter extends CustomPainter {
  @override void paint(Canvas canvas, Size size) {
    canvas.drawPath(
      Path()
        ..addRect(Rect.fromLTWH(0, 0, size.width, size.height))
        ..addRRect(RRect.fromRectAndRadius(
          Rect.fromLTWH(
            (size.width - _kFrameW) / 2,
            (size.height - _kFrameH) / 2 + (size.height / 2) * _kFrameYOffsetFraction,
            _kFrameW,
            _kFrameH,
          ),
          const Radius.circular(6)))
        ..fillType = PathFillType.evenOdd,
      Paint()..color = Colors.black.withOpacity(0.62)..style = PaintingStyle.fill,
    );
  }
  @override bool shouldRepaint(_) => false;
}

class _BracketPainter extends CustomPainter {
  final Color color;
  const _BracketPainter({required this.color});
  @override void paint(Canvas canvas, Size size) {
    final p = Paint()..color = color..strokeWidth = 3.5
      ..strokeCap = StrokeCap.square..style = PaintingStyle.stroke;
    const len = 22.0;
    final w = size.width; final h = size.height;
    canvas.drawLine(Offset(0, len), Offset.zero, p);
    canvas.drawLine(Offset.zero, Offset(len, 0), p);
    canvas.drawLine(Offset(w-len, 0), Offset(w, 0), p);
    canvas.drawLine(Offset(w, 0), Offset(w, len), p);
    canvas.drawLine(Offset(0, h-len), Offset(0, h), p);
    canvas.drawLine(Offset(0, h), Offset(len, h), p);
    canvas.drawLine(Offset(w-len, h), Offset(w, h), p);
    canvas.drawLine(Offset(w, h), Offset(w, h-len), p);
    
    // Middle horizontal guide line
    final midPaint = Paint()
      ..color = color.withOpacity(0.5)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;
    const dashWidth = 8.0;
    const dashSpace = 6.0;
    double startX = 30.0;
    final midY = h / 2;
    while (startX < w - 30) {
      final endX = (startX + dashWidth).clamp(0.0, w - 30);
      canvas.drawLine(Offset(startX, midY), Offset(endX, midY), midPaint);
      startX += dashWidth + dashSpace;
    }
  }
  @override bool shouldRepaint(covariant _BracketPainter o) => o.color != color;
}

// ── Confirm dialog widget ─────────────────────────────────────────
class _ConfirmDialog extends StatefulWidget {
  final String detected;
  const _ConfirmDialog({required this.detected});

  @override
  State<_ConfirmDialog> createState() => _ConfirmDialogState();
}

class _ConfirmDialogState extends State<_ConfirmDialog> {
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.detected);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      insetPadding: const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
      child: SingleChildScrollView(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('Confirm Plate Number',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
            const SizedBox(height: 16),
            Text(
              widget.detected.isEmpty
                  ? 'No plate detected. Type it manually:'
                  : 'Scanner read this plate.\nCorrect it if needed:',
              style: TextStyle(color: Colors.grey[600], fontSize: 13, height: 1.5),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _controller,
              autofocus: true,
              textCapitalization: TextCapitalization.characters,
              textAlign: TextAlign.center,
              style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 5,
                  color: Color(0xFF1A1A1A)),
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.grey[100],
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none),
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                helperText: 'Plate: NHM4030   Conduction: RB0827',
                helperStyle:
                    TextStyle(color: Colors.grey[400], fontSize: 11),
              ),
            ),
            const SizedBox(height: 20),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(null),
                child: const Text('Cancel',
                    style: TextStyle(color: Colors.grey)),
              ),
              const SizedBox(width: 12),
              ElevatedButton(
                onPressed: () {
                  final v = _controller.text
                      .toUpperCase()
                      .replaceAll(RegExp(r'[^A-Z0-9]'), '');
                  Navigator.of(context).pop(v.isEmpty ? null : v);
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFF0000),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  elevation: 0,
                ),
                child: const Text('Search',
                    style: TextStyle(fontWeight: FontWeight.w700)),
              ),
            ]),
          ]),
        ),
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  final String label, example;
  const _Pill({required this.label, required this.example});
  @override Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
    decoration: BoxDecoration(color: Colors.black54,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white24)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
        decoration: BoxDecoration(color: const Color(0xFFFF0000),
            borderRadius: BorderRadius.circular(4)),
        child: Text(label, style: const TextStyle(color: Colors.white,
            fontSize: 9, fontWeight: FontWeight.w800)),
      ),
      const SizedBox(width: 6),
      Text(example, style: const TextStyle(color: Colors.white70,
          fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 1)),
    ]),
  );
}