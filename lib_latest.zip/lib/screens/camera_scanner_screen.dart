import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import '../services/firestore_service.dart';
import '../models/vehicle_model.dart';
import '../widgets/vehicle_result_popup.dart';

class CameraScannerScreen extends StatefulWidget {
  const CameraScannerScreen({super.key});

  @override
  State<CameraScannerScreen> createState() => _CameraScannerScreenState();
}

class _CameraScannerScreenState extends State<CameraScannerScreen> {
  CameraController? _controller;
  final _textRecognizer = TextRecognizer();
  final _firestoreService = FirestoreService();

  bool _cameraReady = false;
  bool _processing = false;
  String _hint = 'Point camera at a plate number';
  String? _cameraError;

  @override
  void initState() {
    super.initState();
    _initCamera();
  }

  Future<void> _initCamera() async {
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        setState(() => _cameraError = 'No camera found on this device.');
        return;
      }

      final camera = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => cameras.first,
      );

      _controller = CameraController(
        camera,
        ResolutionPreset.high,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.jpeg,
      );

      await _controller!.initialize();
      if (mounted) setState(() => _cameraReady = true);
    } catch (e) {
      if (mounted) setState(() => _cameraError = 'Camera error: $e');
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    _textRecognizer.close();
    super.dispose();
  }

  Future<void> _capture() async {
    if (_processing ||
        _controller == null ||
        !_controller!.value.isInitialized) return;

    setState(() {
      _processing = true;
      _hint = 'Scanning...';
    });

    try {
      final image = await _controller!.takePicture();
      final inputImage = InputImage.fromFilePath(image.path);
      final recognized = await _textRecognizer.processImage(inputImage);

      String? foundPlate;

      // Scan recognized text for plate numbers OR conduction stickers
      for (final block in recognized.blocks) {
        for (final line in block.lines) {
          final cleaned = line.text
              .replaceAll(RegExp(r'[^a-zA-Z0-9]'), '')
              .toUpperCase();

          // Plate number: 6–7 alphanumeric
          if (cleaned.length >= 6 &&
              cleaned.length <= 7 &&
              RegExp(r'^[A-Z0-9]{6,7}$').hasMatch(cleaned)) {
            foundPlate = cleaned;
            break;
          }
          // Conduction sticker: CS + 6 alphanumeric = 8 chars total
          if (cleaned.length == 8 &&
              RegExp(r'^CS[A-Z0-9]{6}$').hasMatch(cleaned)) {
            foundPlate = cleaned;
            break;
          }
        }
        if (foundPlate != null) break;
      }

      if (foundPlate != null) {
        setState(() => _hint = 'Found: $foundPlate — Searching...');
        final vehicles = await _firestoreService.searchVehicle(foundPlate);
        if (mounted) _showResult(vehicles, foundPlate);
      } else {
        setState(() => _hint = 'No plate detected. Try again.');
        await Future.delayed(const Duration(seconds: 2));
        if (mounted) setState(() => _hint = 'Point camera at a plate number');
      }
    } catch (e) {
      if (mounted) {
        setState(() => _hint = 'Scan error. Please try again.');
        await Future.delayed(const Duration(seconds: 2));
        if (mounted) setState(() => _hint = 'Point camera at a plate number');
      }
    } finally {
      if (mounted) setState(() => _processing = false);
    }
  }

  void _showResult(List<VehicleModel> vehicles, String plate) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      useSafeArea: true,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: vehicles.isNotEmpty ? 0.88 : 0.5,
        minChildSize: 0.4,
        maxChildSize: 0.95,
        expand: false,
        builder: (_, __) => VehicleResultPopup(
          vehicles: vehicles,
          searchedPlate: plate,
          onScanAnother: () => Navigator.pop(context),
          onBackToDashboard: () {
            Navigator.pop(context);
            Navigator.pop(context);
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          if (_cameraReady && _controller != null)
            Positioned.fill(child: CameraPreview(_controller!))
          else if (_cameraError != null)
            _buildCameraError()
          else
            const Center(
              child: CircularProgressIndicator(color: Color(0xFFFF0000)),
            ),

          if (_cameraReady)
            Positioned.fill(
              child: CustomPaint(painter: _OverlayPainter()),
            ),

          // Top bar
          SafeArea(
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.arrow_back_ios_rounded,
                          color: Colors.white, size: 18),
                    ),
                  ),
                  const SizedBox(width: 14),
                  const Text('Scan Plate Number',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          ),

          // Scan frame + hint
          if (_cameraReady)
            Align(
              alignment: const Alignment(0, 0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    width: 270,
                    height: 96,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: _processing
                            ? const Color(0xFFFF0000)
                            : Colors.white,
                        width: 2.5,
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 9),
                    decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (_processing) ...[
                          const SizedBox(
                            width: 13, height: 13,
                            child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Color(0xFFFF0000)),
                          ),
                          const SizedBox(width: 8),
                        ],
                        Text(_hint,
                            style: const TextStyle(
                                color: Colors.white, fontSize: 13)),
                      ],
                    ),
                  ),
                ],
              ),
            ),

          // Shutter button
          if (_cameraReady)
            Positioned(
              bottom: 48,
              left: 0,
              right: 0,
              child: Center(
                child: GestureDetector(
                  onTap: _capture,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 150),
                    width: 74,
                    height: 74,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _processing
                          ? Colors.grey[700]
                          : const Color(0xFFFF0000),
                      border:
                          Border.all(color: Colors.white, width: 3.5),
                      boxShadow: _processing
                          ? []
                          : [
                              BoxShadow(
                                color: const Color(0xFFFF0000)
                                    .withValues(alpha: 0.5),
                                blurRadius: 20,
                                spreadRadius: 4,
                              )
                            ],
                    ),
                    child: _processing
                        ? const Padding(
                            padding: EdgeInsets.all(22),
                            child: CircularProgressIndicator(
                                strokeWidth: 2.5, color: Colors.white),
                          )
                        : const Icon(Icons.camera_alt_rounded,
                            color: Colors.white, size: 32),
                  ),
                ),
              ),
            ),

          if (_cameraReady)
            Positioned(
              bottom: 24, left: 0, right: 0,
              child: Center(
                child: Text(
                  'Tap the button to capture',
                  style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.6),
                      fontSize: 12),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildCameraError() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.camera_alt_outlined,
                color: Colors.grey, size: 56),
            const SizedBox(height: 16),
            Text(_cameraError!,
                style: const TextStyle(color: Colors.white70, fontSize: 14),
                textAlign: TextAlign.center),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Go Back'),
            ),
          ],
        ),
      ),
    );
  }
}

class _OverlayPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black.withValues(alpha: 0.58)
      ..style = PaintingStyle.fill;

    const frameW = 270.0;
    const frameH = 96.0;
    final left = (size.width - frameW) / 2;
    final top =
        size.height * 0.5 - frameH / 2 - size.height * 0.029;

    final path = Path()
      ..addRect(Rect.fromLTWH(0, 0, size.width, size.height))
      ..addRRect(RRect.fromRectAndRadius(
        Rect.fromLTWH(left, top, frameW, frameH),
        const Radius.circular(12),
      ))
      ..fillType = PathFillType.evenOdd;

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_) => false;
}