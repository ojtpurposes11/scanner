import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../models/vehicle_model.dart';
import '../widgets/search_widget.dart';
import '../widgets/vehicle_result_popup.dart';
import 'camera_scanner_screen.dart';
import 'entry_screen.dart';

class CollectorDashboard extends StatefulWidget {
  const CollectorDashboard({super.key});

  @override
  State<CollectorDashboard> createState() => _CollectorDashboardState();
}

class _CollectorDashboardState extends State<CollectorDashboard> {

  void _logout() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Sign Out',
            style: TextStyle(fontWeight: FontWeight.w700)),
        content: const Text('Are you sure you want to sign out?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);
              await AuthService().signOut();
              if (mounted) {
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const EntryScreen()),
                  (_) => false,
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFF0000),
              foregroundColor: Colors.white,
              elevation: 0,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            child: const Text('Sign Out'),
          ),
        ],
      ),
    );
  }

  void _openVoiceSearch() => _showSearchSheet(mode: SearchMode.voice);
  void _openManualSearch() => _showSearchSheet(mode: SearchMode.manual);

  void _showSearchSheet({SearchMode mode = SearchMode.manual}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      useSafeArea: true,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.55,
        minChildSize: 0.4,
        maxChildSize: 0.9,
        expand: false,
        builder: (_, __) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 36, height: 4,
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              SearchWidget(
                initialMode: mode,
                onScanCamera: () {
                  Navigator.pop(context);
                  Navigator.push(context, MaterialPageRoute(
                      builder: (_) => const CameraScannerScreen()));
                },
                onResult: (vehicles, plate) {
                  Navigator.pop(context);
                  _showResult(vehicles, plate, mode);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showResult(List<VehicleModel> vehicles, String plate, SearchMode mode) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      useSafeArea: true,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: vehicles.isNotEmpty ? 0.88 : 0.5,
        minChildSize: 0.4,
        maxChildSize: 0.95,
        expand: false,
        builder: (_, __) => VehicleResultPopup(
          vehicles: vehicles,
          searchedPlate: plate,
          searchMode: mode,
          onScanAnother: () {
            Navigator.pop(context);
            if (mode == SearchMode.camera) {
              Navigator.push(context, MaterialPageRoute(
                  builder: (_) => const CameraScannerScreen()));
            } else {
              _showSearchSheet(mode: mode);
            }
          },
          onBackToDashboard: () => Navigator.pop(context),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F7F7),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildTopBar(),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const _SectionLabel(label: 'Search Vehicle'),
                    const SizedBox(height: 12),

                    // Camera — opens camera scanner directly
                    _DashCard(
                      icon: Icons.camera_alt_outlined,
                      label: 'Camera Scan',
                      subtitle: 'Scan a plate using your camera',
                      filled: true,
                      onTap: () => Navigator.push(context,
                          MaterialPageRoute(
                              builder: (_) => const CameraScannerScreen())),
                    ),
                    const SizedBox(height: 12),

                    // Voice — opens voice-only search sheet
                    _DashCard(
                      icon: Icons.mic_none_rounded,
                      label: 'Voice Search',
                      subtitle: 'Search by speaking the plate number',
                      filled: false,
                      onTap: _openVoiceSearch,
                    ),
                    const SizedBox(height: 12),

                    // Manual — opens text-only search sheet
                    _DashCard(
                      icon: Icons.search_rounded,
                      label: 'Type Search',
                      subtitle: 'Manually type the plate number',
                      filled: true,
                      onTap: _openManualSearch,
                    ),
                    // No Admin Tools / Upload Database for Field Collectors
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showAboutDialog() {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: const Color(0xFFFF0000),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Icon(Icons.directions_car_rounded,
                    color: Colors.white, size: 32),
              ),
              const SizedBox(height: 14),
              const Text('Convergent Plate Scanner',
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF1A1A1A))),
              const SizedBox(height: 4),
              const Text('Version 2.0',
                  style: TextStyle(fontSize: 12, color: Colors.grey)),
              const SizedBox(height: 20),
              _AboutRow(icon: Icons.groups_rounded,
                  label: 'Developed By',
                  value: 'Convergent IT Interns'),
              _AboutRow(icon: Icons.calendar_today_rounded,
                  label: 'Established',
                  value: '2026'),
              _AboutRow(icon: Icons.business_rounded,
                  label: 'Organization',
                  value: 'Convergent'),
              _AboutRow(icon: Icons.shield_outlined,
                  label: 'Purpose',
                  value: 'Vehicle plate tracking & lookup for field collectors'),
              _AboutRow(icon: Icons.cloud_outlined,
                  label: 'Backend',
                  value: 'Firebase Firestore — real-time cloud sync'),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFF0000),
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text('Close',
                      style: TextStyle(fontWeight: FontWeight.w600)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTopBar() {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      child: Row(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Field collector icon
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  color: const Color(0xFF1A1A1A),
                  borderRadius: BorderRadius.circular(13),
                ),
                child: const Icon(Icons.directions_car_filled_rounded,
                    color: Colors.white, size: 26),
              ),
              const SizedBox(width: 12),
              const Text('Field Dashboard',
                  style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF1A1A1A))),
            ],
          ),
          const Spacer(),
          // Info button
          GestureDetector(
            onTap: _showAboutDialog,
            child: Icon(Icons.info_outline_rounded,
                size: 22, color: Colors.grey[600]),
          ),
          const SizedBox(width: 14),
          // Sign out
          GestureDetector(
            onTap: _logout,
            child: const Icon(Icons.logout_rounded,
                size: 22, color: Color(0xFF1A1A1A)),
          ),
        ],
      ),
    );
  }
}

// ── Section label ────────────────────────────────────────────────

class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Text(label,
        style: const TextStyle(
            fontSize: 14, fontWeight: FontWeight.w600, color: Colors.grey));
  }
}

// ── Full-width dashboard card ────────────────────────────────────

class _DashCard extends StatefulWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  // filled=true → solid red (Camera, Type Search)
  // filled=false → white with red border (Voice Search)
  final bool filled;
  final VoidCallback onTap;

  const _DashCard({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.filled,
    required this.onTap,
  });

  @override
  State<_DashCard> createState() => _DashCardState();
}

class _DashCardState extends State<_DashCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final Color bgColor = widget.filled ? const Color(0xFFFF0000) : Colors.white;
    final Color iconCircleBg = widget.filled
        ? Colors.white.withValues(alpha: 0.25)
        : Colors.red[50]!;
    final Color iconColor =
        widget.filled ? Colors.white : const Color(0xFFFF0000);
    final Color titleColor =
        widget.filled ? Colors.white : const Color(0xFFFF0000);
    final Color subtitleColor = widget.filled
        ? Colors.white.withValues(alpha: 0.8)
        : Colors.grey[500]!;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: const Duration(milliseconds: 100),
        child: Container(
          width: double.infinity,
          padding:
              const EdgeInsets.symmetric(vertical: 32, horizontal: 24),
          decoration: BoxDecoration(
            color: bgColor,
            borderRadius: BorderRadius.circular(18),
            border: widget.filled
                ? null
                : Border.all(
                    color: const Color(0xFFFF0000), width: 1.5),
            boxShadow: widget.filled
                ? [
                    BoxShadow(
                      color: const Color(0xFFFF0000)
                          .withValues(alpha: 0.18),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    )
                  ]
                : [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.04),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    )
                  ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                    color: iconCircleBg, shape: BoxShape.circle),
                child: Icon(widget.icon, color: iconColor, size: 30),
              ),
              const SizedBox(height: 14),
              Text(widget.label,
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                      color: titleColor)),
              const SizedBox(height: 5),
              Text(widget.subtitle,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 13,
                      color: subtitleColor,
                      height: 1.4)),
            ],
          ),
        ),
      ),
    );
  }
}

// ── About row widget ─────────────────────────────────────────────

class _AboutRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _AboutRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 16, color: const Color(0xFFFF0000)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: TextStyle(
                        fontSize: 11,
                        color: Colors.grey[500],
                        fontWeight: FontWeight.w500)),
                const SizedBox(height: 1),
                Text(value,
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF1A1A1A),
                        height: 1.3)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}