import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Allowed credentials
  static const Map<String, String> _credentials = {
    'admin@convergent.com': 'conv_admin2026',
    'field@convergent.com': 'conv_field2026',
  };

  static const Map<String, String> _roles = {
    'admin@convergent.com': 'Admin',
    'field@convergent.com': 'Field Collector',
  };

  Future<Map<String, dynamic>> signIn(String email, String password) async {
    final normalizedEmail = email.trim().toLowerCase();

    // Validate against allowed credentials first
    if (!_credentials.containsKey(normalizedEmail) ||
        _credentials[normalizedEmail] != password) {
      return {'success': false, 'error': 'Invalid email or password.'};
    }

    try {
      await _auth.signInWithEmailAndPassword(
        email: normalizedEmail,
        password: password,
      );
      return {
        'success': true,
        'role': _roles[normalizedEmail],
        'email': normalizedEmail,
      };
    } on FirebaseAuthException catch (e) {
      // Auto-create user if not yet in Firebase Auth
      if (e.code == 'user-not-found' || e.code == 'invalid-credential') {
        try {
          await _auth.createUserWithEmailAndPassword(
            email: normalizedEmail,
            password: password,
          );
          return {
            'success': true,
            'role': _roles[normalizedEmail],
            'email': normalizedEmail,
          };
        } catch (_) {
          return {
            'success': false,
            'error': 'Could not create account. Check Firebase Auth settings.',
          };
        }
      }
      return {
        'success': false,
        'error': e.message ?? 'Authentication failed. Try again.',
      };
    } catch (e) {
      return {'success': false, 'error': 'Unexpected error: $e'};
    }
  }

  Future<void> signOut() async {
    await _auth.signOut();
  }

  String getRoleFromEmail(String email) {
    return _roles[email.toLowerCase()] ?? 'Unknown';
  }

  User? get currentUser => _auth.currentUser;
}
