// Web camera screen — Roboflow detection + Plate Recognizer OCR
// Used instead of camera_scanner_screen.dart on web builds.
//
// Pipeline:
//   1. User taps "Take Photo" or "Upload from Gallery"
//   2. Photo shown as preview — no processing yet
//   3. User taps "Scan Plate"
//      a. Roboflow API     → detects WHERE the plate is (bounding box)
//      b. Canvas API       → crops the plate region + 15% padding
//      c. Plate Recognizer → reads plate text from cropped image
//      d. _fix()/_tryTokens() → corrects OCR errors (same as mobile)
//   4. Auto-search DB → show result immediately if found
//      or confirm dialog if not found / no plate detected
//
// Free tiers:
//   • Roboflow:         1,000 requests/month
//   • Plate Recognizer: 2,500 reads/month — platerecognizer.com
//
// Setup:
//   1. Go to app.platerecognizer.com → sign up free
//   2. Dashboard → API Tokens → copy your token
//   3. Paste token below as _kPlateRecognizerToken
//
// Required:
//   • lib/services/roboflow_service.dart

// ignore_for_file: avoid_web_libraries_in_flutter

import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
// dart:html — browser file input + Canvas cropping. No extra packages needed.
// Works on all browsers including Safari iOS.
// ignore: deprecated_member_use
import 'dart:html' as html;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart' as http_media;
import '../services/firestore_service.dart';
import '../services/roboflow_service.dart';
import '../models/vehicle_model.dart';
import '../widgets/vehicle_result_popup.dart';

// ── Philippine plate formats (mirrors camera_scanner_screen.dart) ─
final _rxPlate = RegExp(r'^[A-Z]{3}[0-9]{4}$');
final _rxOld   = RegExp(r'^[A-Z]{3}[0-9]{3}$');
final _rxCS    = RegExp(r'^[A-Z]{2}[0-9]{4}[A-Z]?$');

bool _isValid(String s) =>
    _rxPlate.hasMatch(s) || _rxOld.hasMatch(s) || _rxCS.hasMatch(s);

// ── Position-aware OCR correction (identical to mobile) ──────────
String? _fix(String s) {
  const toL = {'0':'O','1':'I','8':'B','5':'S','2':'Z','6':'G'};
  const toD = {'O':'0','I':'1','B':'8','S':'5','Z':'2','G':'6','Q':'0'};
  String L(String c) => toL[c] ?? c;
  String D(String c) => toD[c] ?? c;
  bool isLetter(String c) => c.codeUnitAt(0) >= 65 && c.codeUnitAt(0) <= 90;
  if (s.length == 7) {
    final f = '${L(s[0])}${L(s[1])}${L(s[2])}${D(s[3])}${D(s[4])}${D(s[5])}${D(s[6])}';
    if (_isValid(f)) return f;
    final l0 = L(s[0]); final l1 = L(s[1]);
    if (isLetter(l0) && isLetter(l1)) {
      final f2 = '$l0$l1${D(s[2])}${D(s[3])}${D(s[4])}${D(s[5])}${L(s[6])}';
      if (_isValid(f2)) return f2;
    }
  }
  if (s.length == 6) {
    final f = '${L(s[0])}${L(s[1])}${L(s[2])}${D(s[3])}${D(s[4])}${D(s[5])}';
    if (_isValid(f)) return f;
    final l0 = L(s[0]); final l1 = L(s[1]);
    if (isLetter(l0) && isLetter(l1)) {
      final f2 = '$l0$l1${D(s[2])}${D(s[3])}${D(s[4])}${D(s[5])}';
      if (_isValid(f2)) return f2;
    }
  }
  return null;
}

// ── Sliding window token extraction (identical to mobile) ─────────
String? _tryTokens(List<String> tokens) {
  for (final token in tokens) {
    for (final len in [7, 6]) {
      if (token.length < len) continue;
      for (int i = 0; i <= token.length - len; i++) {
        final r = _fix(token.substring(i, i + len));
        if (r != null) return r;
      }
    }
  }
  final joined = tokens.where((t) => t.length <= 8).join('');
  for (final len in [7, 6]) {
    if (joined.length < len) continue;
    for (int i = 0; i <= joined.length - len; i++) {
      final r = _fix(joined.substring(i, i + len));
      if (r != null) return r;
    }
  }
  return null;
}

// ── Crop plate region using HTML Canvas ───────────────────────────
// Roboflow returns center x/y + width/height relative to the full image.
// We draw the full image onto a hidden Canvas, then extract just the
// plate bounding box region as a data URL for Tesseract.
// Padding of 10% is added so plate edges are never clipped.
Future<String> _cropPlateFromImage(
    Uint8List imageBytes, PlateDetection detection) async {
  final completer = Completer<String>();

  // Load image into a browser Image element to get dimensions
  final blob    = html.Blob([imageBytes]);
  final blobUrl = html.Url.createObjectUrlFromBlob(blob);
  final img     = html.ImageElement();

  img.onLoad.listen((_) {
    final imgW = img.naturalWidth.toDouble();
    final imgH = img.naturalHeight.toDouble();

    final padX = detection.width  * 0.15;
    final padY = detection.height * 0.15;

    final left   = ((detection.x - detection.width  / 2) - padX).clamp(0, imgW - 1);
    final top    = ((detection.y - detection.height / 2) - padY).clamp(0, imgH - 1);
    final right  = ((detection.x + detection.width  / 2) + padX).clamp(0, imgW);
    final bottom = ((detection.y + detection.height / 2) + padY).clamp(0, imgH);

    final cropW = (right  - left).toInt();
    final cropH = (bottom - top ).toInt();

    final canvas = html.CanvasElement(width: cropW, height: cropH);
    final ctx    = canvas.context2D;

    ctx.drawImageScaledFromSource(
      img,
      left.toDouble(), top.toDouble(),
      cropW.toDouble(), cropH.toDouble(),
      0, 0,
      cropW.toDouble(), cropH.toDouble(),
    );

    // ✅ FIX 1: Revoke AFTER drawing is complete, not before
    // Revoking before toDataUrl() causes blank crops on Android/Safari
    final dataUrl = canvas.toDataUrl('image/png');
    html.Url.revokeObjectUrl(blobUrl);
    completer.complete(dataUrl);
  });

  img.onError.listen((_) {
    // ✅ FIX 1: Revoke on error path too
    html.Url.revokeObjectUrl(blobUrl);
    // Fallback — FileReader for full image
    final reader = html.FileReader();
    reader.readAsDataUrl(html.Blob([imageBytes]));
    reader.onLoad.listen((_) {
      // ✅ FIX 2: Safe cast for Android — result may be String or JSObject
      final result = reader.result;
      final dataUrl = result is String
          ? result
          : result.toString();
      completer.complete(dataUrl);
    });
    reader.onError.listen((_) => completer.completeError('Image load failed'));
  });

  img.src = blobUrl;
  return completer.future;
}

// ── Full image as data URL (fallback when Roboflow finds nothing) ─
Future<String> _imageToDataUrl(Uint8List bytes) {
  final completer = Completer<String>();
  final reader    = html.FileReader();
  reader.readAsDataUrl(html.Blob([bytes]));
  reader.onLoad.listen((_) {
    // ✅ FIX 2: Safe cast — Android Chrome returns JSObject, not String
    final result = reader.result;
    completer.complete(result is String ? result : result.toString());
  });
  reader.onError.listen((_) => completer.completeError('Read failed'));
  return completer.future;
}

// ── Plate Recognizer config ──────────────────────────────────────
// 1. Sign up free at app.platerecognizer.com
// 2. Dashboard → API Tokens → copy your token
// 3. Paste it below — free tier: 2,500 reads/month
const _kPlateRecognizerToken = '7ff33db4a1e211bb79da90e1ef434cc15a1a6658';
const _kPlateRecognizerUrl   =
    'https://api.platerecognizer.com/v1/plate-reader/';

// ── Plate Recognizer OCR call ─────────────────────────────────────
// Sends cropped plate image as multipart form data.
// Returns detected plate text or null.
// No CORS issues — Plate Recognizer explicitly allows browser requests.
Future<String?> _runPlateRecognizer(Uint8List imageBytes) async {
  if (_kPlateRecognizerToken == 'YOUR_PLATE_RECOGNIZER_TOKEN') {
    throw Exception(
      'Plate Recognizer token not set.\n\n'
      'Steps:\n'
      '1. Go to app.platerecognizer.com\n'
      '2. Sign up free (2,500 reads/month)\n'
      '3. Dashboard → API Tokens → copy token\n'
      '4. Paste into camera_scanner_screen_web.dart',
    );
  }

  final request = http.MultipartRequest('POST',
      Uri.parse(_kPlateRecognizerUrl));

  // ✅ FIX 3: Safari requires explicit headers for CORS preflight to pass
  request.headers['Authorization'] = 'Token $_kPlateRecognizerToken';
  request.headers['Accept']        = 'application/json';
  // Origin header not needed — browser sets it automatically.
  // Plate Recognizer allows all origins on their API.

  // Philippines region hint — improves plate format recognition
  request.fields['regions'] = 'ph';
  // mmc = make/model/color — disable to speed up response
  request.fields['mmc']     = 'false';

  request.files.add(http.MultipartFile.fromBytes(
    'upload',
    imageBytes,
    filename: 'plate.jpg',
    contentType: http_media.MediaType('image', 'jpeg'),
  ));

  final streamed = await request.send().timeout(
    const Duration(seconds: 15),
    onTimeout: () => throw Exception(
        'Plate Recognizer timed out. Check your internet connection.'),
  );
  final response = await http.Response.fromStream(streamed);

  if (response.statusCode != 200 && response.statusCode != 201) {
    throw Exception(
        'Plate Recognizer error ${response.statusCode}: ${response.body}');
  }

  final json    = jsonDecode(response.body) as Map<String, dynamic>;
  final results = json['results'] as List<dynamic>? ?? [];

  if (results.isEmpty) return null;

  // Take the highest confidence result
  results.sort((a, b) =>
      ((b['score'] as num?) ?? 0).compareTo((a['score'] as num?) ?? 0));

  final plate = results.first['plate']?.toString().toUpperCase().trim();
  return (plate != null && plate.isNotEmpty) ? plate : null;
}

// ── Convert data URL back to raw bytes ───────────────────────────
Future<Uint8List> _dataUrlToBytes(String dataUrl) async {
  // Data URL format: "data:image/png;base64,<base64data>"
  final comma = dataUrl.indexOf(',');
  if (comma < 0) throw Exception('Invalid data URL');
  final base64Data = dataUrl.substring(comma + 1);
  return base64Decode(base64Data);
}

// ─────────────────────────────────────────────────────────────────
class CameraScannerScreen extends StatefulWidget {
  const CameraScannerScreen({super.key});
  @override
  State<CameraScannerScreen> createState() => _WebScannerState();
}

class _WebScannerState extends State<CameraScannerScreen> {
  final _db        = FirestoreService();
  final _roboflow  = RoboflowService();

  bool       _processing  = false;
  String     _status      = '';
  String?    _error;
  Uint8List? _previewBytes;

  // ── Open browser file input ───────────────────────────────────
  // useCamera = true  → capture="environment" (rear camera on phones)
  // useCamera = false → gallery / file picker
  // Appending to document.body before .click() is required for Safari iOS.
  Future<Uint8List?> _openFilePicker({required bool useCamera}) async {
    final input = html.FileUploadInputElement()
      ..accept = 'image/*'
      ..style.display = 'none';

    if (useCamera) input.setAttribute('capture', 'environment');

    html.document.body!.append(input);
    input.click();

    final completer = Completer<Uint8List?>();

    input.onChange.listen((_) {
      final files = input.files;
      if (files == null || files.isEmpty) {
        if (!completer.isCompleted) completer.complete(null);
        return;
      }
      final reader = html.FileReader();
      reader.readAsArrayBuffer(files[0]);
      reader.onLoad.listen((_) {
        if (completer.isCompleted) return;
        final result = reader.result;
        // ✅ FIX 2: Android Chrome may return ByteBuffer wrapped in JSObject
        if (result is Uint8List) {
          completer.complete(result);
        } else if (result is List<int>) {
          completer.complete(Uint8List.fromList(result));
        } else {
          // ByteBuffer fallback — used on some Android Chrome versions
          // Convert JS ArrayBuffer → Dart Uint8List via typed_data
          try {
            final buf   = result as ByteBuffer;
            completer.complete(buf.asUint8List());
          } catch (_) {
            completer.complete(null);
          }
        }
      });
      reader.onError.listen((_) {
        if (!completer.isCompleted) completer.complete(null);
      });
    });

    input.onAbort.listen((_) {
      if (!completer.isCompleted) completer.complete(null);
    });

    final bytes = await completer.future.timeout(
      const Duration(minutes: 5),
      onTimeout: () => null,
    ).catchError((_) => null);

    input.remove();
    return bytes;
  }

  // ── Stage 1: Pick image → show preview only ───────────────────
  Future<void> _pickImage({required bool useCamera}) async {
    setState(() {
      _error        = null;
      _previewBytes = null;
      _status       = '';
    });

    final bytes = await _openFilePicker(useCamera: useCamera);
    if (bytes == null) return;

    setState(() {
      _previewBytes = bytes;
      _status       = 'Photo ready — tap "Scan Plate" to detect the plate number.';
    });
  }

  // ── Stage 2: Full pipeline → Roboflow → crop → Tesseract ──────
  Future<void> _scanPlate() async {
    if (_previewBytes == null) return;

    // ── Step A: Roboflow detects plate location ──────────────────
    setState(() { _processing = true; _error = null; _status = 'Detecting plate...'; });

    List<PlateDetection> detections = [];
    try {
      detections = await _roboflow.detectPlates(_previewBytes!);
    } catch (e) {
      // Roboflow failed — skip to Tesseract on full image
      detections = [];
    }

    final best = _roboflow.getBestDetection(detections);

    // ── Step B: Crop plate region (or use full image as fallback) ─
    setState(() { _status = 'Cropping plate region...'; });

    String imageDataUrl;
    bool   usedCrop = false;
    try {
      if (best != null && best.confidence >= 0.25) {
        imageDataUrl = await _cropPlateFromImage(_previewBytes!, best);
        usedCrop     = true;
      } else {
        imageDataUrl = await _imageToDataUrl(_previewBytes!);
      }
    } catch (e) {
      imageDataUrl = await _imageToDataUrl(_previewBytes!);
    }

    // ── Step C: Plate Recognizer reads the plate text ───────────
    setState(() { _status = 'Reading plate text...'; });

    // Convert data URL back to bytes if we cropped, else use original
    final ocrBytes = usedCrop
        ? await _dataUrlToBytes(imageDataUrl)
        : _previewBytes!;

    String? rawPlate;
    try {
      rawPlate = await _runPlateRecognizer(ocrBytes);
    } catch (e) {
      setState(() {
        _processing = false;
        _error      = e.toString().replaceFirst('Exception: ', '');
      });
      return;
    }

    // ── Step D: Correct OCR errors → extract plate ─────────────
    // Plate Recognizer already returns clean text but we still run
    // _fix() to correct any remaining character ambiguities
    String? plate;
    if (rawPlate != null) {
      // Clean and try direct fix first
      final cleaned = rawPlate.replaceAll(RegExp(r'[^A-Za-z0-9]'), '').toUpperCase();
      plate = _fix(cleaned) ?? _tryTokens([cleaned]);
    }

    if (!mounted) return;

    // ── Step E: Auto-search if valid plate detected ───────────
    // Mirrors mobile behaviour: if OCR reads a valid plate,
    // go straight to DB search — no confirm dialog needed.
    // Only show confirm dialog if OCR found nothing or result
    // not in DB, so user can type manually.
    if (plate != null) {
      setState(() { _status = 'Searching database...'; });
      await _autoSearch(plate);
    } else {
      setState(() { _processing = false; _status = ''; });
      await _confirmDialog('');
    }
  }

  // ── Auto-search: DB lookup → show result or fallback to confirm ─
  Future<void> _autoSearch(String plate) async {
    try {
      const swaps = {
        'B':'8','8':'B','O':'0','0':'O','I':'1','1':'I',
        'S':'5','5':'S','Z':'2','2':'Z','G':'6','6':'G',
      };
      final variants = <String>{plate};
      for (int i = 0; i < plate.length; i++) {
        final alt = swaps[plate[i]];
        if (alt != null) {
          variants.add(plate.substring(0, i) + alt + plate.substring(i + 1));
        }
      }

      final results = await Future.wait(
          variants.where(_isValid).map((v) => _db.searchVehicle(v)));

      final seen   = <String>{};
      final merged = <VehicleModel>[];
      for (final list in results) {
        for (final v in list) {
          if (seen.add(v.plateNumber)) merged.add(v);
        }
      }

      if (!mounted) return;
      setState(() { _processing = false; _status = ''; });

      if (merged.isNotEmpty) {
        // ✅ Found — show result immediately (same as mobile)
        _showResult(merged, plate);
      } else {
        // ❌ Not found — show confirm so user can correct the plate
        await _confirmDialog(plate);
      }
    } catch (e) {
      if (mounted) {
        setState(() { _processing = false; _error = 'Search failed: $e'; });
      }
    }
  }

  // ── Confirm / edit detected plate ────────────────────────────
  Future<void> _confirmDialog(String detected) async {
    final ctrl = TextEditingController(text: detected);

    final confirmed = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                  color: Colors.red[50],
                  borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.document_scanner_rounded,
                  color: Color(0xFFFF0000), size: 20),
            ),
            const SizedBox(width: 10),
            const Text('Confirm Plate',
                style: TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w700)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              detected.isEmpty
                  ? 'No plate detected. Type it manually:'
                  : 'Detected plate number.\nCorrect it if needed:',
              style: TextStyle(fontSize: 13, color: Colors.grey[600]),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: ctrl,
              autofocus: true,
              maxLength: 7,
              textCapitalization: TextCapitalization.characters,
              style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 6),
              decoration: InputDecoration(
                counterText: '',
                hintText: 'e.g. NHM4030',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12)),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: const BorderSide(
                      color: Color(0xFFFF0000), width: 2),
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, null),
            child: const Text('Cancel',
                style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton.icon(
            onPressed: () =>
                Navigator.pop(context, ctrl.text.trim().toUpperCase()),
            icon: const Icon(Icons.search_rounded,
                color: Colors.white, size: 18),
            label: const Text('Search',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700)),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFF0000),
              elevation: 0,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
          ),
        ],
      ),
    );

    if (confirmed == null || confirmed.isEmpty || !mounted) return;

    // ── DB search with variant expansion ──────────────────────
    setState(() { _processing = true; _status = 'Searching database...'; });

    try {
      const swaps = {
        'B':'8','8':'B','O':'0','0':'O','I':'1','1':'I',
        'S':'5','5':'S','Z':'2','2':'Z','G':'6','6':'G',
      };
      final variants = <String>{confirmed};
      for (int i = 0; i < confirmed.length; i++) {
        final alt = swaps[confirmed[i]];
        if (alt != null) {
          variants.add(
              confirmed.substring(0, i) + alt + confirmed.substring(i + 1));
        }
      }

      final results = await Future.wait(
          variants.where(_isValid).map((v) => _db.searchVehicle(v)));

      final seen   = <String>{};
      final merged = <VehicleModel>[];
      for (final list in results) {
        for (final v in list) {
          if (seen.add(v.plateNumber)) merged.add(v);
        }
      }

      if (!mounted) return;
      setState(() { _processing = false; _status = ''; });
      _showResult(merged, confirmed);
    } catch (e) {
      setState(() {
        _processing = false;
        _error      = 'Search failed: $e';
      });
    }
  }

  // ── Result popup ──────────────────────────────────────────────
  void _showResult(List<VehicleModel> vehicles, String plate) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      useSafeArea: true,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: vehicles.isNotEmpty ? 0.88 : 0.5,
        minChildSize: 0.4,
        maxChildSize: 0.95,
        expand: false,
        builder: (_, __) => VehicleResultPopup(
          vehicles: vehicles,
          searchedPlate: plate,
          searchMode: SearchMode.camera,
          onScanAnother: () {
            Navigator.pop(context);
            setState(() {
              _previewBytes = null;
              _error        = null;
              _status       = '';
            });
          },
          onTypeSearchAnother: () => Navigator.pop(context),
          onScanAgain: () {
            Navigator.pop(context);
            setState(() {
              _previewBytes = null;
              _error        = null;
              _status       = '';
            });
          },
          onBackToDashboard: () => Navigator.pop(context),
        ),
      ),
    );
  }

  // ── Build ─────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text('Scan Plate',
            style: TextStyle(
                color: Colors.white, fontWeight: FontWeight.w700)),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 32),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              // ── Photo preview / placeholder ──────────────────
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: _previewBytes != null
                    ? Stack(
                        children: [
                          Image.memory(
                            _previewBytes!,
                            height: 240,
                            width: double.infinity,
                            fit: BoxFit.cover,
                          ),
                          if (!_processing)
                            Positioned(
                              top: 10, right: 10,
                              child: GestureDetector(
                                onTap: () => setState(() {
                                  _previewBytes = null;
                                  _status       = '';
                                  _error        = null;
                                }),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 6),
                                  decoration: BoxDecoration(
                                    color: Colors.black
                                        .withValues(alpha: 0.6),
                                    borderRadius:
                                        BorderRadius.circular(20),
                                  ),
                                  child: const Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(Icons.close_rounded,
                                          color: Colors.white,
                                          size: 14),
                                      SizedBox(width: 4),
                                      Text('Clear',
                                          style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 12,
                                              fontWeight:
                                                  FontWeight.w600)),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                        ],
                      )
                    : Container(
                        height: 240,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Colors.grey[900],
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.document_scanner_rounded,
                                size: 64, color: Colors.grey[700]),
                            const SizedBox(height: 14),
                            Text('Photo will appear here',
                                style: TextStyle(
                                    color: Colors.grey[600],
                                    fontSize: 14)),
                            const SizedBox(height: 4),
                            Text('Take a photo or upload from gallery',
                                style: TextStyle(
                                    color: Colors.grey[700],
                                    fontSize: 12)),
                          ],
                        ),
                      ),
              ),

              const SizedBox(height: 20),

              // ── Spinner + status ──────────────────────────────
              if (_processing) ...[
                Center(
                  child: Column(
                    children: [
                      const CircularProgressIndicator(
                          color: Color(0xFFFF0000), strokeWidth: 3),
                      const SizedBox(height: 14),
                      Text(_status,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              color: Colors.white70, fontSize: 14)),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
              ],

              // ── Ready hint ────────────────────────────────────
              if (!_processing &&
                  _status.isNotEmpty &&
                  _previewBytes != null) ...[
                Row(
                  children: [
                    Icon(Icons.check_circle_rounded,
                        color: Colors.green[400], size: 16),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(_status,
                          style: TextStyle(
                              color: Colors.green[400],
                              fontSize: 13,
                              fontWeight: FontWeight.w500)),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
              ],

              // ── Error banner ──────────────────────────────────
              if (_error != null && !_processing) ...[
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.red[900]!.withValues(alpha: 0.45),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.red[700]!),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.error_outline_rounded,
                          color: Colors.redAccent, size: 18),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(_error!,
                            style: const TextStyle(
                                color: Colors.redAccent,
                                fontSize: 13,
                                height: 1.5)),
                      ),
                      GestureDetector(
                        onTap: () => setState(() => _error = null),
                        child: const Icon(Icons.close_rounded,
                            color: Colors.redAccent, size: 16),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
              ],

              // ── Buttons ───────────────────────────────────────
              if (!_processing) ...[

                // ── No photo: Take Photo + Gallery ────────────
                if (_previewBytes == null) ...[
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: ElevatedButton.icon(
                      onPressed: () => _pickImage(useCamera: true),
                      icon: const Icon(Icons.camera_alt_rounded,
                          color: Colors.white, size: 22),
                      label: const Text('Take Photo',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w700)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFFF0000),
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: OutlinedButton.icon(
                      onPressed: () => _pickImage(useCamera: false),
                      icon: const Icon(Icons.photo_library_rounded,
                          color: Colors.white70, size: 22),
                      label: const Text('Upload from Gallery',
                          style: TextStyle(
                              color: Colors.white70,
                              fontSize: 15,
                              fontWeight: FontWeight.w600)),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(
                            color: Colors.white30, width: 1.5),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Tips
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.grey[900],
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.tips_and_updates_outlined,
                                size: 14, color: Colors.grey[400]),
                            const SizedBox(width: 6),
                            Text('Tips for best results',
                                style: TextStyle(
                                    color: Colors.grey[400],
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600)),
                          ],
                        ),
                        const SizedBox(height: 10),
                        _tip('Fill the frame with the plate number'),
                        _tip('Good lighting — avoid glare and shadows'),
                        _tip('Keep the photo steady and in focus'),
                        _tip('Plate should be the main subject of the photo'),
                      ],
                    ),
                  ),

                // ── Photo loaded: Scan + Retake/Gallery ──────
                ] else ...[

                  // Primary — Scan Plate
                  SizedBox(
                    width: double.infinity,
                    height: 58,
                    child: ElevatedButton.icon(
                      onPressed: _scanPlate,
                      icon: const Icon(
                          Icons.document_scanner_rounded,
                          color: Colors.white, size: 22),
                      label: const Text('Scan Plate',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w800)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFFF0000),
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),

                  // Secondary — Retake | Gallery
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _pickImage(useCamera: true),
                          icon: const Icon(Icons.camera_alt_rounded,
                              color: Colors.white60, size: 18),
                          label: const Text('Retake',
                              style: TextStyle(
                                  color: Colors.white60,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600)),
                          style: OutlinedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(
                                vertical: 14),
                            side: const BorderSide(
                                color: Colors.white24, width: 1.5),
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.circular(30)),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _pickImage(useCamera: false),
                          icon: const Icon(
                              Icons.photo_library_rounded,
                              color: Colors.white60, size: 18),
                          label: const Text('Gallery',
                              style: TextStyle(
                                  color: Colors.white60,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600)),
                          style: OutlinedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(
                                vertical: 14),
                            side: const BorderSide(
                                color: Colors.white24, width: 1.5),
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.circular(30)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _tip(String text) => Padding(
    padding: const EdgeInsets.only(bottom: 5),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('• ',
            style: TextStyle(color: Colors.grey[600], fontSize: 12)),
        Expanded(
          child: Text(text,
              style: TextStyle(
                  color: Colors.grey[500],
                  fontSize: 12,
                  height: 1.4)),
        ),
      ],
    ),
  );
}