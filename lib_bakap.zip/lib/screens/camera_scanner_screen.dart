import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import '../services/firestore_service.dart';
import '../models/vehicle_model.dart';
import '../widgets/vehicle_result_popup.dart';

class CameraScannerScreen extends StatefulWidget {
  const CameraScannerScreen({super.key});

  @override
  State<CameraScannerScreen> createState() => _CameraScannerScreenState();
}

class _CameraScannerScreenState extends State<CameraScannerScreen> {
  CameraController? _controller;
  final _textRecognizer = TextRecognizer();
  final _firestoreService = FirestoreService();

  bool _cameraReady = false;
  bool _processing = false;
  String _hint = 'Point camera at a plate number';
  String? _cameraError;

  @override
  void initState() {
    super.initState();
    _initCamera();
  }

  Future<void> _initCamera() async {
    try {
      final cameras = await availableCameras();
      if (cameras.isEmpty) {
        setState(() => _cameraError = 'No camera found on this device.');
        return;
      }

      // Prefer back camera
      final camera = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => cameras.first,
      );

      _controller = CameraController(
        camera,
        ResolutionPreset.high,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.jpeg,
      );

      await _controller!.initialize();
      if (mounted) setState(() => _cameraReady = true);
    } catch (e) {
      if (mounted) {
        setState(() => _cameraError = 'Camera error: $e');
      }
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    _textRecognizer.close();
    super.dispose();
  }

  Future<void> _capture() async {
    if (_processing ||
        _controller == null ||
        !_controller!.value.isInitialized) return;

    setState(() {
      _processing = true;
      _hint = 'Scanning...';
    });

    try {
      final image = await _controller!.takePicture();
      final inputImage = InputImage.fromFilePath(image.path);
      final recognized = await _textRecognizer.processImage(inputImage);

      String? foundPlate;

      // ── Strategy: find the LARGEST text on the plate ────────────
      // The plate number characters are physically much bigger than
      // "REGISTERED", "REGION 3", "MV FILE NO." etc.
      // ML Kit gives us a boundingBox per element — we use height
      // as a proxy for font size, then validate the format.
      //
      // Valid formats:
      //   Conduction sticker : 2 letters + 4 digits  → 6 chars  e.g. RB0827
      //   Standard plate     : 3 letters + 4 digits  → 7 chars  e.g. ABC1234
      //   Old format         : 3 letters + 3 digits  → 6 chars  e.g. ABC123

      // Collect every element with its bounding box height
      final candidates = <_OcrCandidate>[];

      for (final block in recognized.blocks) {
        for (final line in block.lines) {
          for (final element in line.elements) {
            final raw = element.text
                .replaceAll(RegExp(r'[^a-zA-Z0-9]'), '')
                .toUpperCase();
            final h = element.boundingBox?.height ?? 0;
            if (raw.isNotEmpty) {
              candidates.add(_OcrCandidate(text: raw, height: h.toDouble()));
            }
          }
        }
      }

      // Sort by bounding box height descending — biggest text first
      candidates.sort((a, b) => b.height.compareTo(a.height));

      // Take the top candidates by height (top 30% of max height)
      final maxH = candidates.isEmpty ? 0.0 : candidates.first.height;
      final tall = candidates
          .where((c) => c.height >= maxH * 0.55)
          .map((c) => c.text)
          .toList();

      // Try to assemble the plate from tall elements (they may be split
      // into individual characters or groups by the OCR engine)
      final joined = tall.join('').toUpperCase();

      // Score each candidate against known plate patterns
      // Priority 1: exact 6-char conduction sticker  [A-Z]{2}[0-9]{4}
      // Priority 2: exact 7-char standard plate       [A-Z]{3}[0-9]{4}
      // Priority 3: exact 6-char old plate            [A-Z]{3}[0-9]{3}
      // Priority 4: any 6-7 alphanumeric from joined string
      final patterns = [
        RegExp(r'[A-Z]{2}[0-9]{4}'),   // conduction sticker
        RegExp(r'[A-Z]{3}[0-9]{4}'),   // standard plate
        RegExp(r'[A-Z]{3}[0-9]{3}'),   // old plate
        RegExp(r'[A-Z0-9]{6,7}'),       // fallback
      ];

      for (final pat in patterns) {
        // First try individual tall elements
        for (final c in tall) {
          if (pat.hasMatch(c)) {
            final m = pat.firstMatch(c);
            if (m != null) {
              foundPlate = m.group(0);
              break;
            }
          }
        }
        if (foundPlate != null) break;

        // Then try joined string
        final m = pat.firstMatch(joined);
        if (m != null) {
          foundPlate = m.group(0);
          break;
        }
      }

      // Reject known noise words that OCR commonly picks up on plates
      const _noiseWords = {
        'REGISTERED', 'REGION', 'MVFILE', 'DEALER', 'ARIAL',
        'BLACK', 'PLATE', 'NUMBER', 'CONDUCTION', 'STICKER',
      };
      if (foundPlate != null && _noiseWords.contains(foundPlate)) {
        foundPlate = null;
      }

      if (foundPlate != null) {
        setState(() => _hint = 'Found: $foundPlate — Searching...');
        final vehicles = await _firestoreService.searchVehicle(foundPlate);
        if (mounted) _showResult(vehicles, foundPlate);
      } else {
        setState(() => _hint = 'No plate detected. Try again.');
        await Future.delayed(const Duration(seconds: 2));
        if (mounted) setState(() => _hint = 'Point camera at a plate number');
      }
    } catch (e) {
      if (mounted) {
        setState(() => _hint = 'Scan error. Please try again.');
        await Future.delayed(const Duration(seconds: 2));
        if (mounted) setState(() => _hint = 'Point camera at a plate number');
      }
    } finally {
      if (mounted) setState(() => _processing = false);
    }
  }

  void _showResult(List<VehicleModel> vehicles, String plate) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      useSafeArea: true,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: vehicles.isNotEmpty ? 0.88 : 0.5,
        minChildSize: 0.4,
        maxChildSize: 0.95,
        expand: false,
        builder: (_, __) => VehicleResultPopup(
          vehicles: vehicles,
          searchedPlate: plate,
          searchMode: SearchMode.camera,
          onScanAnother: () => Navigator.pop(context),
          onTypeSearchAnother: () {
            // Pop the result sheet, then pop the camera screen
            // so the dashboard can open the type search sheet
            Navigator.pop(context);
            Navigator.pop(context, 'typeSearch');
          },
          onScanAgain: () {
            // Just dismiss the result sheet — camera stays open ready to scan
            Navigator.pop(context);
          },
          onBackToDashboard: () {
            Navigator.pop(context);
            Navigator.pop(context);
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Camera preview
          if (_cameraReady && _controller != null)
            Positioned.fill(child: CameraPreview(_controller!))
          else if (_cameraError != null)
            _buildCameraError()
          else
            const Center(
              child: CircularProgressIndicator(color: Color(0xFFFF0000)),
            ),

          // Dim overlay with scan window cutout
          if (_cameraReady)
            Positioned.fill(
              child: CustomPaint(painter: _OverlayPainter()),
            ),

          // Top bar
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Icon(Icons.arrow_back_ios_rounded,
                          color: Colors.white, size: 18),
                    ),
                  ),
                  const SizedBox(width: 14),
                  const Text('Scan Plate Number',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          ),

          // Scan frame + hint — centered on screen
          if (_cameraReady)
            Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Frame
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    width: 270,
                    height: 96,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: _processing
                            ? const Color(0xFFFF0000)
                            : Colors.white,
                        width: 2.5,
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  const SizedBox(height: 20),
                  // Status chip
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 9),
                    decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        if (_processing) ...[
                          const SizedBox(
                            width: 13,
                            height: 13,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Color(0xFFFF0000),
                            ),
                          ),
                          const SizedBox(width: 8),
                        ],
                        Text(_hint,
                            style: const TextStyle(
                                color: Colors.white, fontSize: 13)),
                      ],
                    ),
                  ),
                ],
              ),
            ),

          // Shutter button
          if (_cameraReady)
            Positioned(
              bottom: 48,
              left: 0,
              right: 0,
              child: Center(
                child: GestureDetector(
                  onTap: _capture,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 150),
                    width: 74,
                    height: 74,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _processing
                          ? Colors.grey[700]
                          : const Color(0xFFFF0000),
                      border: Border.all(color: Colors.white, width: 3.5),
                      boxShadow: _processing
                          ? []
                          : [
                              BoxShadow(
                                color: const Color(0xFFFF0000).withOpacity(0.5),
                                blurRadius: 20,
                                spreadRadius: 4,
                              )
                            ],
                    ),
                    child: _processing
                        ? const Padding(
                            padding: EdgeInsets.all(22),
                            child: CircularProgressIndicator(
                                strokeWidth: 2.5, color: Colors.white),
                          )
                        : const Icon(Icons.camera_alt_rounded,
                            color: Colors.white, size: 32),
                  ),
                ),
              ),
            ),

          // Bottom hint
          if (_cameraReady)
            Positioned(
              bottom: 24,
              left: 0,
              right: 0,
              child: Center(
                child: Text(
                  'Tap the button to capture',
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.6), fontSize: 12),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildCameraError() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.camera_alt_outlined, color: Colors.grey, size: 56),
            const SizedBox(height: 16),
            Text(
              _cameraError!,
              style: const TextStyle(color: Colors.white70, fontSize: 14),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Go Back'),
            ),
          ],
        ),
      ),
    );
  }
}

class _OverlayPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black.withOpacity(0.58)
      ..style = PaintingStyle.fill;

    const frameW = 270.0;
    const frameH = 96.0;
    final left = (size.width - frameW) / 2;
    final top = (size.height - frameH) / 2;

    final path = Path()
      ..addRect(Rect.fromLTWH(0, 0, size.width, size.height))
      ..addRRect(RRect.fromRectAndRadius(
        Rect.fromLTWH(left, top, frameW, frameH),
        const Radius.circular(12),
      ))
      ..fillType = PathFillType.evenOdd;

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_) => false;
}

// ── OCR candidate helper ─────────────────────────────────────────
class _OcrCandidate {
  final String text;
  final double height;
  const _OcrCandidate({required this.text, required this.height});
}